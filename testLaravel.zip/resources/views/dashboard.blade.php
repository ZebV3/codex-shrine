<div>
    <a href="{{ route('profile') }}">Profile</a>
</div>
