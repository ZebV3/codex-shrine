<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Example</title>
</head>
<body>
    <form action="/profile" method="post">
        <?php echo csrf_field(); ?>
    </form>
</body>
</html><?php /**PATH C:\laragon\www\testLaravel\resources\views/example.blade.php ENDPATH**/ ?>