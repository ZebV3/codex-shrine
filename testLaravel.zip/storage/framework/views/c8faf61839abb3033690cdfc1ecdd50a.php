<div>
    <a href="<?php echo e(route('profile')); ?>">Profile</a>
</div>
<?php /**PATH C:\laragon\www\testLaravel\resources\views/dashboard.blade.php ENDPATH**/ ?>